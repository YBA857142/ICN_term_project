To run the code, type:
mkdir cache
python3 ./PA/backend_server1.py
python3 ./PA/backend_server2.py
python3 ./load_balancer.py
in turn